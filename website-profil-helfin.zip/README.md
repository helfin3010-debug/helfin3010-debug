# Website Profil Pribadi — Helfin Amilia Anggara

Website portofolio satu halaman dengan tema navy, maroon, dan sage. Dibuat menggunakan HTML, CSS, dan JavaScript sederhana.

## Cara memasang di GitHub Pages
1. Buat repository baru di GitHub, misalnya `profil-helfin`.
2. Upload file `index.html` ke bagian utama (root) repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`, lalu klik **Save**.
6. Tunggu beberapa menit. GitHub akan menampilkan alamat website di bagian Pages.

## Kustomisasi galeri
Kotak pada bagian Galeri Kreativitas masih berupa desain ilustratif. Untuk memakai foto sendiri, ubah isi setiap `<article class="gallery-tile">` atau tambahkan elemen `<img>` pada bagian tersebut.

## Privasi
Karena website GitHub Pages dapat dilihat publik, template ini sengaja hanya menampilkan domisili umum (Blitar, Jawa Timur). Nomor HP, alamat rumah lengkap, dan email tidak ditampilkan. Sebaiknya jangan memasang data pribadi tersebut di website publik.
